// Get the Learn More button element
const learnMoreBtn = document.getElementById('learnMoreBtn');

// Add event listener for click event
learnMoreBtn.addEventListener('click', () => {
  // Replace this with your desired action when the button is clicked
  alert('You clicked the Learn More button!');
});


document.addEventListener('DOMContentLoaded', function() {
  // Get the Learn More button element
  const learnMoreBtn = document.getElementById('learnMoreBtn');

  // Add event listener for click event
  learnMoreBtn.addEventListener('click', () => {
    // Replace this with your desired action when the button is clicked
    alert('You clicked the Learn More button!');
  });
});
