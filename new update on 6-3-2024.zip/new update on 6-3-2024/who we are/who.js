 // JavaScript functionality
 document.getElementById('toggleOfferBtn').addEventListener('click', function() {
  var offerSection = document.getElementById('offerSection');
  if (offerSection.style.display === 'none') {
    offerSection.style.display = 'block';
  } else {
    offerSection.style.display = 'none';
  }
});

// Simulating loading completion after 3 seconds
setTimeout(() => {
  document.getElementById('loading-container').classList.add('loading-hide');
}, 3000);


// Get references to the button and the hidden page
const openPageBtn = document.getElementById('openPageBtn');
const hiddenPage = document.getElementById('hiddenPage');

// Add click event listener to the open button
openPageBtn.addEventListener('click', function() {
  // Show the hidden page
  hiddenPage.style.display = 'block';
});

// Get reference to the close button inside the hidden page
const closePageBtn = document.getElementById('closePageBtn');

// Add click event listener to the close button
closePageBtn.addEventListener('click', function() {
  // Hide the hidden page
  hiddenPage.style.display = 'none';
});


